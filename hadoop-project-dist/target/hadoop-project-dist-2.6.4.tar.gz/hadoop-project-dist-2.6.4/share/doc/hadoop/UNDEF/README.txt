DUMMY.

Required for the assembly:single goal not to fail because there
are not files in the hadoop-project-dist module.
